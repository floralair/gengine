/*___INFO__MARK_BEGIN__*/
/*****************************************************************************
 *
 *  This code is the Property, a Trade Secret and the Confidential Information
 *  of Univa Corporation.
 *
 *  Copyright Univa Corporation. All Rights Reserved. Access is Restricted.
 *
 *  It is provided to you under the terms of the
 *  Univa Term Software License Agreement.
 *
 *  If you have any questions, please contact our Support Department.
 *
 *  www.univa.com
 *
 ****************************************************************************/
/*___INFO__MARK_END__*/
/**
 * THIS IS AN EXAMPLE HOW TO ACCESS LOAD METRICS FOR
 * INTEL XEON PHI CARDS PROGRAMATICALLY. THE CODE IS
 * ONLY FOR DEMONSTRATION PURPOSES.
 **/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#include "mic_help.h"

#include "MicBasicTypes.h"
#include "MicAccessErrorTypes.h"
#include "MicAccessApi.h"
#include "MicThermalTypes.h"
#include "MicThermalAPI.h"
#include "MicPowerManagerAPI.h"

#define true  1
#define false 0

/* the default values should be alligned with uge_phi_load_sensor_install.sh */

bool show_memory_utilization = true;
bool show_die_temperature    = true;
bool show_board_temperature  = false;
bool show_mem_temperature    = false;
bool show_inlet_temperature  = true;
bool show_outlet_temperature = true;
bool show_fanstatus          = false;
bool show_powerusage         = true;
bool show_powerlimit_physical = false;
bool show_powerlimit_upper_threshold = false;
bool show_powerlimit_lower_threshold = false;
bool show_flash_version      = false;
bool show_driver_version     = true;
bool show_uos_version        = true;
bool show_ecc_state          = true;
bool show_active_cores       = true;

typedef enum _E_CPUSTAT_VALUE
{
    eUser,
    eSystem,
    eIdle,
    eNValues
} E_CPUSTAT_VALUE;

/* API Helpers */

/* Open Mic API */
void initMicAPI(void *accessHandle, MicDeviceOnSystem *adaptersList, U32 *nAdapters)
{
   U32 retVal = MicInitAPI(accessHandle, eTARGET_SCIF_DRIVER, adaptersList, nAdapters);

   if (retVal != MIC_ACCESS_API_SUCCESS) {
      printf ("%s\n", MicGetErrorString(retVal));
      exit(1);
   }

   // To ensure that adapterList doesn't overflow
   if (*nAdapters < 0 || *nAdapters >= MAX_DEVICES) {
      printf ("%s\n", MicGetErrorString(MIC_ACCESS_API_ERROR_UNKNOWN));
      exit(1);
   }
}

void closeAPI(HANDLE *accessHandle) {
   U32 retVal = MicCloseAPI(accessHandle);
   if (retVal != MIC_ACCESS_API_SUCCESS) {
      printf ("%s\n", MicGetErrorString(retVal));
      exit(1);
   }
}

void initAdapter(HANDLE accessHandle, MicDeviceOnSystem* adapter)
{
   U32 retVal = MicInitAdapter(accessHandle, adapter);
   if (retVal != MIC_ACCESS_API_SUCCESS)
   {
      printf ("%s\n", MicGetErrorString(retVal));
      closeAPI(&accessHandle);
      exit(1);
   }
}

void closeAdapter(void *accessHandle) {
   U32 retVal = MicCloseAdapter((HANDLE)accessHandle);
   if (retVal != MIC_ACCESS_API_SUCCESS)
   {
      printf ("%s\n", MicGetErrorString(retVal));
      closeAPI(&accessHandle);
      exit(1);
    }
}

/* Device metrics reporting functions */
static void report_memory(HANDLE accessHandle, const int devId, const char* hostname,
                          U32 *total_max, U32 *free_max, U32 *used_min) {
   if (show_memory_utilization) {
      U32 total = 0;
      U32 free  = 0;
      U32 buff  = 0;
      U32 retVal = MicGetMemoryUtilization(accessHandle, &total, &free, &buff);

      if (retVal != MIC_ACCESS_API_SUCCESS) {
         fprintf(stderr, "%s\n", MicGetErrorString(retVal));
         closeAdapter(accessHandle);
         closeAPI(&accessHandle);
         exit(1);
      }

      printf("%smic.%d.mem_total:%uK\n", hostname, devId, total);
      printf("%smic.%d.mem_free:%uK\n", hostname, devId, free);
      printf("%smic.%d.mem_used:%uK\n", hostname, devId, (total - free));
      printf("%smic.%d.mem_bufs:%uK\n", hostname, devId, buff);

      /* save host global values */
      if (*total_max < total) {
         *total_max = total;
      }

      if (*free_max < free) {
         *free_max = free;
      }

      if (*used_min > (total - free)) {
         *used_min = (total - free);
      }
   }
}

/* Report host global memory related values */
static void report_global_memory(const char* hostname, U32 total_max, U32 free_max, U32 used_min) {
   if (show_memory_utilization) {
      printf("%smic_mem_total_max:%uK\n", hostname, total_max);
      printf("%smic_mem_free_max:%uK\n", hostname, free_max);
      printf("%smic_mem_used_min:%uK\n", hostname, used_min);
   }
}

static void report_temperature(HANDLE accessHandle, const int devId, const char* hostname,
                               U32* max_die, U32* max_board, U32* max_inlet, U32* max_outlet,
                               U32* max_mem) {
   U32 *temperatures = (U32 *) NULL;
   int END_TEMP_SENSOR = eMicThermalVddq;
   int sensor;
   U32 returningSize = 0;
   U32 retVal = MIC_ACCESS_API_ERROR_UNKNOWN;

   for (sensor = eMicThermalBoard; sensor <= END_TEMP_SENSOR; sensor++) {
      temperatures = (U32 *) malloc(returningSize);
      returningSize = 16;
      retVal = MicGetTemperature(accessHandle, (E_MIC_THERMAL_TYPE) sensor,
                                 temperatures, &returningSize);
      if (retVal != MIC_ACCESS_API_SUCCESS) {
         continue;
      }

      switch (sensor) {
         case eMicThermalBoard:
            if (show_board_temperature) {
               printf("%smic.%d.temp_board:%u\n",hostname, devId, temperatures[0]);
               if (*max_board < temperatures[0]) {
                  *max_board = temperatures[0];
               }
            }
            break;
         case eMicThermalDevMem:
            if (show_mem_temperature) {
               printf("%smic.%d.temp_mem:%u\n",hostname, devId, temperatures[0]);
               if (*max_mem < temperatures[0]) {
                  *max_mem = temperatures[0];
               }
            }
            break;
         case eMicThermalDie:
            if (show_die_temperature) {
               printf("%smic.%d.temp_die:%u\n",hostname, devId, temperatures[0]);
               if (*max_die < temperatures[0]) {
                  *max_die = temperatures[0];
               }
            }
            break;
         case eMicThermalFin:
            if (show_inlet_temperature) {
               printf("%smic.%d.temp_inlet:%u\n",hostname, devId, temperatures[0]);
               if (*max_inlet < temperatures[0]) {
                  *max_inlet = temperatures[0];
               }
            }
            break;
         case eMicThermalFout:
            if (show_outlet_temperature) {
               printf("%smic.%d.temp_outlet:%u\n",hostname, devId, temperatures[0]);
               if (*max_outlet < temperatures[0]) {
                  *max_outlet = temperatures[0];
               }
            }
            break;
      }
      free(temperatures);
   } // loop metrics
}

static void report_global_temperature(const char* hostname, U32 max_die, U32 max_board, U32 max_inlet,
                                      U32 max_outlet, U32 max_mem) {
   if (show_die_temperature) {
      printf("%smic_temp_die_max:%u\n", hostname, max_die);
   }
   if (show_board_temperature) {
      printf("%smic_temp_board_max:%u\n", hostname, max_board);
   }
   if (show_inlet_temperature) {
      printf("%smic_temp_inlet_max:%u\n", hostname, max_inlet);
   }
   if (show_outlet_temperature) {
      printf("%smic_temp_outlet_max:%u\n", hostname, max_outlet);
   }
   if (show_mem_temperature) {
      printf("%smic_temp_mem_max:%u\n", hostname, max_mem);
   }
}

static void report_fanstatus(HANDLE accessHandle, const int devId, const char* hostname) {
   PMicFanStatusData FanStatus = (PMicFanStatusData) NULL;
   U32 returnSize = sizeof(MicFanStatusData);
   U32 retVal = MIC_ACCESS_API_ERROR_UNKNOWN;
   U32 sensorCount = 0;
   int i;


   if (show_fanstatus == true) {
      FanStatus = (PMicFanStatusData) malloc(returnSize);
      if (FanStatus == NULL) {
         printf("Out of memory. Exiting.\n");
         closeAdapter(accessHandle);
         closeAPI(&accessHandle);
         exit(1);
      }

      sensorCount = returnSize / sizeof(MicFanStatusData);

      retVal = MicGetFanStatus(accessHandle, FanStatus, &returnSize);
      if (retVal == MIC_ACCESS_API_SUCCESS) {
         for (i = 0; i < sensorCount; i++) {
            if (FanStatus[i].scif.enabled) {
               printf("%smic.%d.fan:%s\n",hostname, devId, "TRUE");
            } else {
               printf("%smic.%d.fan:%s\n",hostname, devId, "FALSE");
            }
         }
      }
   }
}

static void report_powerusage(HANDLE accessHandle, const int devId, const char* hostname,
                              U32 *power_usage) {
   if (show_powerusage) {
      U32 watt = 0, retVal;
      MicPwrUsage powerUsage;
      int measurement = 1;

      while (measurement < 6) {
         retVal = MicGetPowerUsage(accessHandle, &powerUsage);
         if (retVal == MIC_ACCESS_API_SUCCESS) {
            watt = powerUsage.total1.prr / 1000000;
            if (watt != 0) {
               break;
            }
         } else {
            break;
         }
         measurement++;
      }
      if (retVal == MIC_ACCESS_API_SUCCESS) {
         printf("%smic.%d.power:%u\n", hostname, devId, watt);
      }
      /* save combined usage of all cards */
      *power_usage += watt;
   }
}

static void report_global_powerusage(const char* hostname, U32 combined_power) {
   if (show_powerusage) {
      printf("%smic_power_combined:%u\n", hostname, combined_power);
   }
}

static void report_powerlimit(HANDLE accessHandle, const int devId, const char* hostname) {
   MicPwrLimit PwrUsgLimit;
   U32 retVal;

   if (show_powerlimit_physical == false && show_powerlimit_upper_threshold == false
          && show_powerlimit_lower_threshold == false) {
      return;
   }

   retVal = MicGetPowerLimit(accessHandle, &PwrUsgLimit);
   if (retVal != MIC_ACCESS_API_SUCCESS) {
      return;
   }

   if (show_powerlimit_physical) {
      printf("%smic.%d.power_physical_limit:%u\n", PwrUsgLimit.phys);
   }

   if (show_powerlimit_upper_threshold) {
      printf("%smic.%d.power_upper_threshold:%u\n", PwrUsgLimit.hmrk);
   }

   if (show_powerlimit_lower_threshold) {
      printf("%smic.%d.power_lower_threshold:%u\n", PwrUsgLimit.lmrk);
   }
}

static void report_driverversion(HANDLE accessHandle, const int devId, const char* hostname) {
   char versionString[MAX_STRING];
   U32 stringSize = sizeof(versionString);

   if (show_flash_version) {
      U32 retVal = MicGetMicVersion(accessHandle, MIC_VERSION_FLASH_IMAGE,
                                    versionString, &stringSize);

      if (retVal == MIC_ACCESS_API_SUCCESS) {
         printf("%smic.%d.flash_image_version:%s\n", hostname, devId, versionString);
      }
   }

   if (show_driver_version) {
      U32 retVal = MicGetMicVersion(accessHandle, MIC_VERSION_HSD,
                                versionString, &stringSize);
      if (retVal == MIC_ACCESS_API_SUCCESS) {
         printf("%smic.%d.host_driver_version:%s\n",hostname, devId, versionString);
      }
   }
}

/* Currently unused! Only for demonstration purposes. */
static void report_processorinfo(HANDLE accessHandle) {
   U8 model, modelExt, type, family, familyExt, stepping, subStepping;

   U32 retVal = MicGetProcessorInfo(accessHandle, &model, &modelExt, &type,
                                    &family, &familyExt, &stepping, &subStepping);

   if (retVal != MIC_ACCESS_API_SUCCESS) {
      return;
   }

   printf("Processor information: %d %d %d %d %d %d %d\n", model, modelExt, type, family,
             familyExt, stepping, subStepping);
}


static void report_uosversion(HANDLE accessHandle, const int devId, const char* hostname) {
   if (show_uos_version) {
      char versionString[MAX_STRING] = { 0 };
      U32 stringSize = sizeof(versionString);
      U32 retVal = MicGetMicVersion(accessHandle, MIC_VERSION_UOS,
                                    versionString, &stringSize);
      if (retVal != MIC_ACCESS_API_SUCCESS) {
         return;
      }
      printf("%smic.%d.uos_version:%s\n", hostname, devId, versionString);
   }
}

static void report_ECCstate(HANDLE accessHandle, const int devId, const char* hostname) {
   if (show_ecc_state) {
      bool mode;
      U32 retVal = MicGetEccMode(accessHandle, &mode);

      if (retVal != MIC_ACCESS_API_SUCCESS) {
         return;
      }
      printf("%smic.%d.ecc_on:%s\n", hostname, devId, mode?"TRUE":"FALSE");
   }
}

static int get_deviceid(HANDLE accessHandle, const int devId, const char* hostname) {
   U32 deviceID = 0;
   U32 retVal = MicGetDeviceID(accessHandle, &deviceID);

   if (retVal != MIC_ACCESS_API_SUCCESS) {
      return;
   }
   printf("Device ID: %d\n", (int)deviceID);

}

static void report_numcores(HANDLE accessHandle, const int devId, const char* hostname, U32* cores, U32* max) {
   if (show_active_cores) {
      U32 numCores= 0;
      U32 retVal = MicGetNumCores(accessHandle, &numCores);

      if (retVal != MIC_ACCESS_API_SUCCESS) {
         return;
      }
      printf("%smic.%d.cores:%u\n", hostname, devId, numCores);
      *cores += numCores;
      if (*max < numCores) {
         *max = numCores;
      }
   }
}

static void report_global_numcores(const char* hostname, U32 combined_cores, U32 cores_max) {
   if (show_active_cores) {
      printf("%smic_cores_combined:%u\n", hostname, combined_cores);
      printf("%smic_cores_max:%u\n", hostname, cores_max);
   }
}

/* Only for demonstration purposes! Currently unused! */
void report_corefrequency(HANDLE accessHandle) {
   U32 buffer[128];
   U32 bufferSize = 128;

   U32 retVal = MicGetFrequency(accessHandle, MIC_CLOCK_MEM, &buffer[0], &bufferSize);

   if (retVal != MIC_ACCESS_API_SUCCESS) {
      return;
   }

   printf("Core frequency in kHz: %d %d %d %d\n", (int)buffer[0], (int)buffer[1], (int) buffer[2], (U32) buffer[3]);
}

/**
 * @brief Returns the amount of Intel Xeon Phi cards installed.
 *
 * MPSS system service must be running.
 *
 * @return Amount of cards.
 */
int get_amount_of_cards() {
   HANDLE accessHandle = NULL;
   U32 nAdapters = MAX_DEVICES;
   MicDeviceOnSystem adaptersList[MAX_DEVICES];

   initMicAPI(&accessHandle, adaptersList, &nAdapters);
   if (accessHandle != NULL) {
      closeAPI(&accessHandle);
   }
   return (int) nAdapters;
}

/**
 * @brief Reports the load for one or all MIC cards.
 *
 * Prints out a number of load values for one or all MIC cards.
 * If the card_nr is -1 the metrics for all cards are reported.
 * This includes global minimum or maximum values (like
 * highest temperature for all cards). The load values must be
 * configured before this function is called. If no configuration
 * is the default values are set.
 *
 * MPSS system service must be running.
 *
 * @param hostName The hostname which is prefix in the output.
 * @param card_nr Either -1 if all cards are reported or the card number.
 */
void load_sensor(const char *hostName, const int card_nr) {
   MicDeviceOnSystem adaptersList[MAX_DEVICES];
   HANDLE accessHandle = NULL;
   U32 nAdapters = MAX_DEVICES;
   U32 adapterNum;
   /* host global min, max, and combined values */
   U32 total_max = 0;
   U32 free_max  = 0;
   U32 used_min  = INT32_MAX;
   /* temperature based */
   U32 max_die    = 0;
   U32 max_board  = 0;
   U32 max_inlet  = 0;
   U32 max_outlet = 0;
   U32 max_mem    = 0;
   /* sum of power usage from all cards */
   U32 combined_power = 0;
   /* sum of all active cores */
   U32 num_cores   = 0;
   U32 max_cores   = 0;
   int start_at_adapter = 0;
   const char* localHostName = NULL;

   if (strcmp(hostName, "") != 0) {
      /* append a ":" at the end of the hostname as a delimitor */
      char* name = malloc(sizeof(char)*strlen(hostName) + 2);
      strncpy(name, hostName, strlen(hostName));
      name[strlen(hostName)] = ':'; /* append ':\0' */
      name[strlen(hostName)+1] = '\0';
      localHostName = name;

   } else {
      localHostName = hostName;
   }

   initMicAPI(&accessHandle, adaptersList, &nAdapters);

   /* only report values for a specific adapter */
   if (card_nr >= 0) {
      start_at_adapter = card_nr;
   }

   for (adapterNum = start_at_adapter; adapterNum < nAdapters; adapterNum++) {
      initAdapter(&accessHandle, &adaptersList[adapterNum]);

      /* If temperature should be reported: do it */
      report_temperature(accessHandle, adapterNum, localHostName, &max_die, &max_board, &max_inlet, &max_outlet, &max_mem);

      /* If fanstatus should be reported: do it */
      report_fanstatus(accessHandle, adapterNum, localHostName);

      /* Report flash image version and host driver version */
      report_driverversion(accessHandle, adapterNum, localHostName);

      /* Report version of uOS on the MIC card. */
      report_uosversion(accessHandle, adapterNum, localHostName);

      /* Report ECC state of memory (can be switch on and off by same SDK) */
      report_ECCstate(accessHandle, adapterNum, localHostName);

      /* Report current power usage */
      report_powerusage(accessHandle, adapterNum, localHostName, &combined_power);

      /* Report the amount of active cores the MIC device has */
      report_numcores(accessHandle, adapterNum, localHostName, &num_cores, &max_cores);

      /* Report memory utilization: total, free, and buffered */
      report_memory(accessHandle, adapterNum, localHostName, &total_max, &free_max, &used_min);

      // Close adapter
      closeAdapter(accessHandle);

      if (card_nr >= 0) {
         /* we selected just one card -> abort */
         break;
      }
   }
   closeAPI(&accessHandle);

   /* report host global values */
   if (card_nr < 0) {
      report_global_temperature(localHostName, max_die, max_board, max_inlet, max_outlet, max_mem);
      report_global_powerusage(localHostName, combined_power);
      report_global_numcores(localHostName, num_cores, max_cores);
      report_global_memory(localHostName, total_max, free_max, used_min);
   }
}

static void set_load_values(const bool state) {
   show_memory_utilization         = state;
   show_die_temperature            = state;
   show_board_temperature          = state;
   show_mem_temperature            = state;
   show_inlet_temperature          = state;
   show_outlet_temperature         = state;
   show_fanstatus                  = state;
   show_powerusage                 = state;
   show_powerlimit_physical        = state;
   show_powerlimit_upper_threshold = state;
   show_powerlimit_lower_threshold = state;
   show_flash_version              = state;
   show_driver_version             = state;
   show_uos_version                = state;
   show_ecc_state                  = state;
   show_active_cores               = state;
}

void turn_load_values_off() {
   set_load_values(false);
}

void turn_load_values_on() {
   set_load_values(true);
}

bool check_and_mark(char* load_value) {

   /* remove new lines at the end */
   int i = 0;
   int len = strlen(load_value);

   if (len <= 1) {
      return true;
   }

   if (load_value[len-1] == '\n') {
      load_value[len-1] = '\0';
      len = strlen(load_value);
   }
   /* report irregular hard to detect spaces */
   for (i = 0; i < len; i++) {
      if (load_value[i] == ' ') {
         printf("Load value %s contains irregular space!\n");
         return false;
      }
   }

   if (strncmp(load_value, "memory_utilization", strlen("memory_utilization")) == 0) {
      show_memory_utilization = true;
   } else if (strncmp(load_value, "die_temperature", strlen("die_temperature")) == 0) {
      show_die_temperature = true;
   } else if (strncmp(load_value, "board_temperature", strlen("board_temperature")) == 0) {
      show_board_temperature = true;
   } else if (strncmp(load_value, "mem_temperature", strlen("mem_temperature")) == 0) {
      show_mem_temperature = true;
   } else if (strncmp(load_value, "inlet_temperature", strlen("inlet_temperature")) == 0) {
      show_inlet_temperature = true;
   } else if (strncmp(load_value, "outlet_temperature", strlen("outlet_temperature")) == 0) {
      show_outlet_temperature = true;
   } else if (strncmp(load_value, "fanstatus", strlen("fanstatus")) == 0) {
      show_fanstatus = true;
   } else if (strncmp(load_value, "powerusage", strlen("powerusage")) == 0) {
      show_powerusage = true;
   } else if (strncmp(load_value, "powerlimit_physical", strlen("powerlimit_physical")) == 0) {
      show_powerlimit_physical = true;
   } else if (strncmp(load_value, "powerlimit_upper_threshold", strlen("powerlimit_upper_threshold")) == 0) {
      show_powerlimit_upper_threshold = true;
   } else if (strncmp(load_value, "powerlimit_lower_threshold", strlen("powerlimit_lower_threshold")) == 0) {
      show_powerlimit_lower_threshold = true;
   } else if (strncmp(load_value, "flash_version", strlen("flash_version")) == 0) {
      show_flash_version = true;
   } else if (strncmp(load_value, "driver_version", strlen("driver_version")) == 0) {
      show_driver_version = true;
   } else if (strncmp(load_value, "uos_version", strlen("uos_version")) == 0) {
      show_uos_version = true;
   } else if (strncmp(load_value, "ecc_state", strlen("ecc_state")) == 0) {
      show_ecc_state = true;
   } else if (strncmp(load_value, "active_cores", strlen("active_cores")) == 0) {
      show_active_cores = true;
   } else {
      printf("Unknown load value: %s\n", load_value);
      return false;
   }

   return true;
}

void read_config_and_set_value(const char *filename) {
   FILE *config = NULL;
   char block[MAX_FILE];
   char *load_value = NULL;

   if (filename == NULL) {
      printf("No file name given.\n");
      exit(1);
   }

   if ((config = fopen(filename, "r")) == NULL) {
      printf("Config file not found!\n");
      exit(1);
   }

   turn_load_values_off();

   while (fgets(block, sizeof(block), config)) {
      char *context = NULL;
      /* either in new lines or space separated load values are allowed */
      if ((load_value = strtok_r(block, " \n", &context)) != NULL) {
         do {
            if (check_and_mark(load_value) != true) {
               fclose(config);
               printf("Error during parsing of config file, aborting!\n");
               exit(1);
            }
         } while ((load_value = strtok_r(NULL, " \n", &context)) != NULL);
      }
   }

   fclose(config);
}

